from flask import Flask, render_template, request,redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///records.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Info(db.Model):
    sno = db.Column(db.Integer , primary_key = True)
    name = db.Column(db.String(200) , nullable = False)
    reg = db.Column(db.String(200) , nullable = False)
    dep = db.Column(db.String(200) , nullable = False)
    date_created = db.Column(db.DateTime , default = datetime.utcnow)

    def __repr__(self) -> str:
        return f"{self.sno} - {self.name}"
    

@app.route('/' , methods=['GET','POST'])
def indexPg():
    
    if request.method=='POST':
        name= request.form['name']
        reg= request.form['reg']
        dep= request.form['dep']

        info= Info(name=name , reg=reg ,dep=dep)
        db.session.add(info)
        db.session.commit()

    allinfo=Info.query.all()
    return render_template('index.html', allinfo=allinfo)

@app.route('/delete/<int:sno>')
def delete(sno):
    todel=Info.query.filter_by(sno=sno).first()
    db.session.delete(todel)
    db.session.commit()
    return redirect("/")


@app.route('/Records')
def records():
    allinfo=Info.query.all()
    return render_template('records.html',allinfo=allinfo)

if __name__ == "__main__":
    app.run(debug=True)
    
    